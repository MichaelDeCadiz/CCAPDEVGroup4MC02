
localStorage.removeItem('session');
window.location.href = 'login.html';
